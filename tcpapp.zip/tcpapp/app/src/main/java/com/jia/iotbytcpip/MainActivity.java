package com.jia.iotbytcpip;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageButton imageButton_link;
    ImageButton imageButton_send;
    ImageButton imageButton_exit;
    EditText editText_ipaddress;
    EditText editText_port;
    EditText editText_data;
    TextView textView_recdata;
    Button button_clean;

    String ip="",port="",senddata="";

    public cmdReceiver cmdReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageButton_link=findViewById(R.id.imageButton_link);
        imageButton_send=findViewById(R.id.imageButton_send);
        imageButton_exit=findViewById(R.id.imageButton_exit);
        button_clean=findViewById(R.id.button_clean);
        editText_ipaddress=findViewById(R.id.editText_ipaddress);
        editText_port=findViewById(R.id.editText_port);
        imageButton_link.setOnClickListener(this);
        imageButton_send.setOnClickListener(this);
        imageButton_exit.setOnClickListener(this);
        button_clean.setOnClickListener(this);
        textView_recdata=findViewById(R.id.textView_recdata);
        editText_data=findViewById(R.id.editText_data);
        //注册广播接收器
        cmdReceiver =new cmdReceiver();
        IntentFilter intentFilter=new IntentFilter();
        intentFilter.addAction("com.example.communication.data");
        registerReceiver(cmdReceiver,intentFilter);

    }
    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.imageButton_link:
            {
                if(!((editText_ipaddress.getText().toString().equals("")))&&(!(editText_ipaddress.getText().toString().equals("")))) {
                    ip = editText_ipaddress.getText().toString();
                    port = editText_port.getText().toString();
                    System.out.println("输入的ip地址为：" + ip + "输入端口为：" + port);
                    Intent intent = new Intent(this, TCPService.class);
                    intent.putExtra("ipaddress", ip);
                    intent.putExtra("port", port);
                    startService(intent);
                    showNormalDialog("连接已启动，可从Tcp服务端（网络串口助手）查看连接成功与否。",0);
                }
                else
                    showNormalDialog("IP或端口号不可以为空",0);

            }break;
            case R.id.imageButton_send:
            {
                if(!(editText_data.getText().toString().equals(""))){
                    senddata = editText_data.getText().toString();
                    byte[] buff = senddata.getBytes();
                    TCPService.send(buff);
                }
                else
                    showNormalDialog("发送数据不可以为空",0);

            }break;
            case R.id.button_clean:
            {
                textView_recdata.setText("无");
            }break;
            case R.id.imageButton_exit:
            {
                showNormalDialog("确定断开连接并退出吗？",1);
            }break;

        }
    }
    private void showNormalDialog(String strtip,final int fun){
        //创建dialog构造器
        AlertDialog.Builder normalDialog = new AlertDialog.Builder(this);
        //设置title
        normalDialog.setTitle("温馨提示：");
        //设置icon
        //normalDialog.setIcon(R.drawable.agriculture);
        //设置内容
        normalDialog.setMessage(strtip);
        //设置按钮
        normalDialog.setPositiveButton(getString(R.string.sure)
                , new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        System.out.println("确定");

                        if(fun==1){
                            MainActivity.this.finish();
                            System.exit(0);
                        }
                    }
                });
        //创建并显示
        normalDialog.create().show();
    }
    private class cmdReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            byte[] receive=intent.getByteArrayExtra("data");
            String recieveData=new String(receive,0,receive.length);
            System.out.println("接收到数据："+recieveData);
            textView_recdata.setText(recieveData);
        }
    }
}

